#!/data/data/com.termux/files/usr/bin/bash
# Système de mise à jour ZAgent (corrigé) : écrit les fichiers, câble l'app,
# crée le workflow de release et pousse sur GitHub.
# Usage :  bash update_system.sh            -> installe et pousse
#          bash update_system.sh --release  -> installe, pousse, puis publie la release 1.0
set -e

echo "== 1/7 Préparation =="
pkg install -y git gh python >/dev/null 2>&1 || true

REPO=$(find ~ -maxdepth 4 -type d -name CodeAgent -exec test -d {}/.git \; -print -quit 2>/dev/null)
if [ -z "$REPO" ]; then
  cd ~ && gh repo clone CodeAgent && REPO=~/CodeAgent
fi
cd "$REPO"
git pull --rebase --autostash

SLUG=$(gh repo view --json nameWithOwner -q .nameWithOwner)
OWNER=${SLUG%/*}
NAME=${SLUG#*/}
echo "Dépôt : $SLUG"

if ! gh secret list | grep -q KEYSTORE_BASE64; then
  echo "❌ Secrets de signature absents (KEYSTORE_BASE64...). Lance d'abord : bash ~/deploy.sh"
  exit 1
fi

PKG_DIR=app/src/main/java/com/zagent/app
if [ ! -d "$PKG_DIR" ]; then
  echo "❌ Dossier $PKG_DIR introuvable : je ne suis pas dans le bon projet."
  exit 1
fi
U="$PKG_DIR/update"
T="app/src/test/java/com/zagent/app/update"
mkdir -p "$U" "$T" app/src/main/res/xml .github/workflows

echo "== 2/7 Code de la mise à jour =="

cat > "$U/UpdateConfig.kt" << EOF
package com.zagent.app.update

object UpdateConfig {
    const val GITHUB_OWNER = "$OWNER"
    const val GITHUB_REPO = "$NAME"
}
EOF

cat > "$U/UpdateModels.kt" << 'EOF'
package com.zagent.app.update

data class ApkAsset(
    val name: String,
    val size: Long,
    val url: String,
    val sha256: String?
)

data class ReleaseInfo(
    val tag: String,
    val notes: String,
    val apk: ApkAsset,
    val sha256Url: String?
)

sealed class ParseResult {
    class Success(val info: ReleaseInfo) : ParseResult()
    class Failure(val message: String) : ParseResult()
}

sealed class UpdateState {
    object Idle : UpdateState()
    object Checking : UpdateState()
    class UpToDate(val currentVersion: String) : UpdateState()
    class Available(val info: ReleaseInfo, val currentVersion: String) : UpdateState()
    class Downloading(val info: ReleaseInfo, val percent: Int, val downloaded: Long, val total: Long) : UpdateState()
    class Ready(val info: ReleaseInfo, val apkPath: String) : UpdateState()
    class NeedsPermission(val info: ReleaseInfo, val apkPath: String) : UpdateState()
    class Error(val message: String, val info: ReleaseInfo? = null) : UpdateState()
}
EOF

cat > "$U/VersionComparator.kt" << 'EOF'
package com.zagent.app.update

/**
 * Compare la version distante (tag GitHub) à la version installée.
 * Les tags de release ont la forme v1.0-b12 : le numéro après "-b" est le versionCode,
 * c'est lui qu'Android utilise pour accepter ou refuser une mise à jour.
 */
object VersionComparator {
    private val BUILD_SUFFIX = Regex("-b(\\d+)$")

    fun buildNumber(tag: String): Long? =
        BUILD_SUFFIX.find(tag.trim())?.groupValues?.get(1)?.toLongOrNull()

    fun isNewer(remoteTag: String, localVersionName: String, localVersionCode: Long): Boolean {
        val remote = remoteTag.trim().removePrefix("v").removePrefix("V")
        if (remote.isEmpty()) return false
        val build = buildNumber(remote)
        if (build != null) return build > localVersionCode
        return compareSemantic(remote, localVersionName.trim().removePrefix("v").removePrefix("V")) > 0
    }

    fun compareSemantic(a: String, b: String): Int {
        val (coreA, preA) = split(a)
        val (coreB, preB) = split(b)
        val size = maxOf(coreA.size, coreB.size)
        for (i in 0 until size) {
            val x = coreA.getOrElse(i) { 0L }
            val y = coreB.getOrElse(i) { 0L }
            if (x != y) return x.compareTo(y)
        }
        return when {
            preA == null && preB == null -> 0
            preA == null -> 1
            preB == null -> -1
            else -> preA.compareTo(preB)
        }
    }

    private fun split(version: String): Pair<List<Long>, String?> {
        val main = version.substringBefore('+')
        val core = main.substringBefore('-')
        val pre = if (main.contains('-')) main.substringAfter('-') else null
        val numbers = core.split('.').map { part -> part.filter { it.isDigit() }.toLongOrNull() ?: 0L }
        return Pair(numbers, pre)
    }
}
EOF

cat > "$U/ReleaseParser.kt" << 'EOF'
package com.zagent.app.update

import org.json.JSONObject

object ReleaseParser {
    private val SHA_REGEX = Regex("^[0-9a-f]{64}$")

    private fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key, "")

    fun normalizeSha(raw: String): String? {
        val value = raw.trim().lowercase()
        return if (SHA_REGEX.matches(value)) value else null
    }

    fun parse(json: String): ParseResult {
        val root = try {
            JSONObject(json)
        } catch (e: Exception) {
            return ParseResult.Failure("Réponse GitHub invalide.")
        }
        val tag = root.str("tag_name").trim()
        if (tag.isEmpty()) return ParseResult.Failure("Release sans numéro de version.")
        val assets = root.optJSONArray("assets")
            ?: return ParseResult.Failure("La release $tag ne contient aucun fichier.")

        var apk: ApkAsset? = null
        val shaFiles = HashMap<String, String>()
        for (i in 0 until assets.length()) {
            val asset = assets.optJSONObject(i) ?: continue
            val name = asset.str("name")
            val url = asset.str("browser_download_url")
            if (name.isBlank() || url.isBlank()) continue
            if (name.endsWith(".apk", ignoreCase = true)) {
                if (apk == null) {
                    val digest = asset.str("digest")
                    val sha = if (digest.startsWith("sha256:", ignoreCase = true)) {
                        normalizeSha(digest.substringAfter(':'))
                    } else {
                        null
                    }
                    apk = ApkAsset(name, asset.optLong("size", -1L), url, sha)
                }
            } else if (name.endsWith(".sha256", ignoreCase = true)) {
                shaFiles[name] = url
            }
        }
        val found = apk ?: return ParseResult.Failure("La release $tag n'a pas d'APK compatible.")
        val info = ReleaseInfo(
            tag = tag,
            notes = cleanNotes(root.str("body")),
            apk = found,
            sha256Url = shaFiles[found.name + ".sha256"]
        )
        return ParseResult.Success(info)
    }

    fun cleanNotes(raw: String): String {
        val lines = raw.lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { it.replace("**", "").replace("`", "").replace(Regex("^[-*•]\\s*"), "").trim() }
            .filter { it.isNotEmpty() }
        return if (lines.isEmpty()) "Corrections et améliorations." else lines.joinToString("\n") { "• $it" }
    }
}
EOF

cat > "$U/ApkVerifier.kt" << 'EOF'
package com.zagent.app.update

import android.content.Context
import android.content.pm.PackageInfo
import android.os.Build
import java.io.File
import java.security.MessageDigest

object AppVersion {
    fun name(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    fun code(context: Context): Long = try {
        codeOf(context.packageManager.getPackageInfo(context.packageName, 0))
    } catch (e: Exception) {
        0L
    }

    @Suppress("DEPRECATION")
    fun codeOf(info: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
}

object ApkVerifier {
    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /** Retourne null si le fichier est valide, sinon un message d'erreur lisible. */
    fun verify(context: Context, file: File, expectedSize: Long, expectedSha256: String?): String? {
        if (!file.exists() || !file.isFile) return "Fichier de mise à jour introuvable."
        if (expectedSize > 0 && file.length() != expectedSize) {
            return "Taille incorrecte : le fichier est incomplet ou corrompu."
        }
        if (expectedSha256 != null && !sha256(file).equals(expectedSha256, ignoreCase = true)) {
            return "Empreinte SHA-256 incorrecte : fichier corrompu ou modifié."
        }
        val archive = context.packageManager.getPackageArchiveInfo(file.absolutePath, 0)
            ?: return "Le fichier téléchargé n'est pas un APK valide."
        if (archive.packageName != context.packageName) {
            return "Cet APK appartient à une autre application."
        }
        if (AppVersion.codeOf(archive) <= AppVersion.code(context)) {
            return "Cette version n'est pas plus récente que celle installée."
        }
        return null
    }
}
EOF

cat > "$U/UpdateDownloadWorker.kt" << 'EOF'
package com.zagent.app.update

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Télécharge l'APK dans le cache privé, dans un fichier .part (reprise possible avec Range),
 * puis vérifie taille, SHA-256, paquet et version avant de le renommer.
 */
class UpdateDownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) { execute() }

    private suspend fun execute(): Result {
        val url = inputData.getString(KEY_URL).orEmpty()
        val name = inputData.getString(KEY_NAME).orEmpty()
        val size = inputData.getLong(KEY_SIZE, -1L)
        val sha = inputData.getString(KEY_SHA)?.takeIf { it.isNotBlank() }
        if (!url.startsWith("https://") || name.isEmpty() || name.contains("/") || name.contains("..")) {
            return fail("Paramètres de téléchargement invalides.")
        }

        val dir = File(applicationContext.cacheDir, "updates")
        dir.mkdirs()
        val finalFile = File(dir, name)
        val part = File(dir, "$name.part")

        if (finalFile.exists()) {
            if (ApkVerifier.verify(applicationContext, finalFile, size, sha) == null) return ok(finalFile)
            finalFile.delete()
        }

        try {
            download(url, part, size)
        } catch (e: IOException) {
            if (runAttemptCount < 3) return Result.retry()
            return fail("Téléchargement interrompu : ${e.localizedMessage ?: "réseau indisponible"}. Réessaie.")
        }

        if (!part.renameTo(finalFile)) return fail("Impossible d'enregistrer le fichier téléchargé.")
        val error = ApkVerifier.verify(applicationContext, finalFile, size, sha)
        if (error != null) {
            finalFile.delete()
            return fail(error)
        }
        return ok(finalFile)
    }

    private suspend fun download(url: String, part: File, expected: Long) {
        var offset = if (part.exists()) part.length() else 0L
        if (expected > 0 && offset > expected) {
            part.delete()
            offset = 0L
        }
        if (expected > 0 && offset == expected) return

        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "ZAgent-Android")
        if (offset > 0) conn.setRequestProperty("Range", "bytes=$offset-")
        try {
            val code = conn.responseCode
            val append: Boolean
            if (code == HttpURLConnection.HTTP_PARTIAL) {
                append = true
            } else if (code == HttpURLConnection.HTTP_OK) {
                append = false
                offset = 0L
            } else {
                throw IOException("HTTP $code")
            }
            val remaining = conn.contentLengthLong
            val total = if (expected > 0) expected else if (remaining > 0) remaining + offset else -1L
            var downloaded = offset
            var lastReport = 0L
            val deadline = System.currentTimeMillis() + MAX_DURATION_MS
            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val buffer = ByteArray(32 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        downloaded += n
                        val now = System.currentTimeMillis()
                        if (now > deadline) throw IOException("délai maximum dépassé")
                        if (now - lastReport > 400) {
                            lastReport = now
                            setProgress(workDataOf(KEY_DOWNLOADED to downloaded, KEY_TOTAL to total))
                        }
                    }
                }
            }
            setProgress(workDataOf(KEY_DOWNLOADED to downloaded, KEY_TOTAL to total))
        } finally {
            conn.disconnect()
        }
    }

    private fun ok(file: File): Result = Result.success(workDataOf(KEY_PATH to file.absolutePath))

    private fun fail(message: String): Result = Result.failure(workDataOf(KEY_ERROR to message))

    companion object {
        const val KEY_URL = "url"
        const val KEY_NAME = "name"
        const val KEY_SIZE = "size"
        const val KEY_SHA = "sha256"
        const val KEY_DOWNLOADED = "downloaded"
        const val KEY_TOTAL = "total"
        const val KEY_PATH = "path"
        const val KEY_ERROR = "error"
        private const val MAX_DURATION_MS = 9 * 60 * 1000L
    }
}
EOF

cat > "$U/UpdateFileProvider.kt" << 'EOF'
package com.zagent.app.update

import androidx.core.content.FileProvider

/** Sous-classe dédiée pour éviter tout conflit avec un autre FileProvider de l'application. */
class UpdateFileProvider : FileProvider()
EOF

cat > "$U/UpdateManager.kt" << 'EOF'
package com.zagent.app.update

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Vérifie la dernière release GitHub, télécharge l'APK avec WorkManager,
 * contrôle son intégrité puis ouvre l'installateur système (avec le consentement de l'utilisateur).
 */
object UpdateManager {
    private const val WORK_NAME = "zagent-update-download"
    private const val PREFS = "zagent_update"
    private const val KEY_DISMISSED = "dismissed_tag"
    private const val STALE_PART_MS = 24L * 60L * 60L * 1000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val checking = AtomicBoolean(false)
    private lateinit var appContext: Context
    private var initialized = false
    private var downloadJob: Job? = null

    private val _state = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val state: StateFlow<UpdateState> = _state.asStateFlow()

    private val _dismissedTag = MutableStateFlow<String?>(null)
    val dismissedTag: StateFlow<String?> = _dismissedTag.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        if (initialized) return
        appContext = context.applicationContext
        initialized = true
        _dismissedTag.value = prefs().getString(KEY_DISMISSED, null)
        cleanupStale()
    }

    fun currentVersionName(): String = if (initialized) AppVersion.name(appContext) else "?"

    // ---------- Vérification ----------

    /** auto = vérification au démarrage (une seule fois par session) ; sinon vérification manuelle. */
    fun check(auto: Boolean) {
        if (!initialized) return
        scope.launch { runCheck(auto) }
    }

    private suspend fun runCheck(auto: Boolean) {
        val current = _state.value
        if (current is UpdateState.Checking || current is UpdateState.Downloading) return
        if (auto && current !is UpdateState.Idle) return
        if (!checking.compareAndSet(false, true)) return
        try {
            if (!auto) setDismissed(null)
            _state.value = UpdateState.Checking
            _state.value = withContext(Dispatchers.IO) { resolveState() }
        } catch (e: Exception) {
            _state.value = UpdateState.Error("Vérification impossible : ${e.localizedMessage ?: "erreur inconnue"}")
        } finally {
            checking.set(false)
        }
    }

    private fun resolveState(): UpdateState {
        val parsed = fetchLatest()
        if (parsed is ParseResult.Failure) return UpdateState.Error(parsed.message)
        val release = (parsed as ParseResult.Success).info

        val name = AppVersion.name(appContext)
        if (!VersionComparator.isNewer(release.tag, name, AppVersion.code(appContext))) {
            deleteAllApks()
            return UpdateState.UpToDate(name)
        }

        val resolved = resolveSha(release)
        if (resolved is ParseResult.Failure) return UpdateState.Error(resolved.message)
        val info = (resolved as ParseResult.Success).info

        val cached = findCachedApk(info)
        return if (cached != null) {
            UpdateState.Ready(info, cached.absolutePath)
        } else {
            UpdateState.Available(info, name)
        }
    }

    private fun fetchLatest(): ParseResult {
        val url = "https://api.github.com/repos/${UpdateConfig.GITHUB_OWNER}/${UpdateConfig.GITHUB_REPO}/releases/latest"
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.setRequestProperty("User-Agent", "ZAgent-Android")
            conn.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            when (val code = conn.responseCode) {
                200 -> ReleaseParser.parse(conn.inputStream.bufferedReader().use { it.readText() })
                404 -> ParseResult.Failure("Aucune release publiée pour le moment.")
                403, 429 -> ParseResult.Failure("Limite GitHub atteinte, réessaie plus tard.")
                else -> ParseResult.Failure("Erreur GitHub (HTTP $code).")
            }
        } catch (e: java.io.IOException) {
            ParseResult.Failure("Pas de connexion, ou GitHub est injoignable.")
        } catch (e: Exception) {
            ParseResult.Failure("Vérification impossible : ${e.localizedMessage ?: "erreur inconnue"}")
        } finally {
            conn?.disconnect()
        }
    }

    private fun httpGetText(url: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "ZAgent-Android")
            if (conn.responseCode == 200) conn.inputStream.bufferedReader().use { it.readText() } else null
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    /** Si l'empreinte n'est pas fournie par l'API, lit le fichier .sha256 publié avec la release. */
    private fun resolveSha(info: ReleaseInfo): ParseResult {
        val shaUrl = info.sha256Url
        if (info.apk.sha256 != null || shaUrl == null) return ParseResult.Success(info)
        val text = httpGetText(shaUrl)
            ?: return ParseResult.Failure("Impossible de récupérer l'empreinte SHA-256 de la mise à jour.")
        val token = text.trim().split(Regex("\\s+")).firstOrNull().orEmpty()
        val sha = ReleaseParser.normalizeSha(token)
            ?: return ParseResult.Failure("Le fichier SHA-256 de la release est invalide.")
        return ParseResult.Success(info.copy(apk = info.apk.copy(sha256 = sha)))
    }

    // ---------- Fichiers ----------

    private fun prefs() = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun updatesDir(): File {
        val dir = File(appContext.cacheDir, "updates")
        dir.mkdirs()
        return dir
    }

    private fun findCachedApk(info: ReleaseInfo): File? {
        val dir = updatesDir()
        dir.listFiles()?.forEach { f ->
            if (f.name != info.apk.name && f.name != info.apk.name + ".part") f.delete()
        }
        val apk = File(dir, info.apk.name)
        if (apk.exists()) {
            if (ApkVerifier.verify(appContext, apk, info.apk.size, info.apk.sha256) == null) return apk
            apk.delete()
        }
        return null
    }

    private fun deleteAllApks() {
        updatesDir().listFiles()?.forEach { it.delete() }
    }

    private fun cleanupStale() {
        try {
            val now = System.currentTimeMillis()
            updatesDir().listFiles()?.forEach { f ->
                val stalePart = f.name.endsWith(".part") && now - f.lastModified() > STALE_PART_MS
                if (f.length() == 0L || stalePart) f.delete()
            }
        } catch (e: Exception) {
            // Nettoyage best-effort : on ignore.
        }
    }

    private fun setDismissed(tag: String?) {
        _dismissedTag.value = tag
        if (!initialized) return
        val editor = prefs().edit()
        if (tag == null) editor.remove(KEY_DISMISSED) else editor.putString(KEY_DISMISSED, tag)
        editor.apply()
    }

    // ---------- Téléchargement ----------

    fun startDownload() {
        if (!initialized) return
        val info = when (val s = _state.value) {
            is UpdateState.Available -> s.info
            is UpdateState.Error -> s.info
            else -> null
        } ?: return

        val data = Data.Builder()
            .putString(UpdateDownloadWorker.KEY_URL, info.apk.url)
            .putString(UpdateDownloadWorker.KEY_NAME, info.apk.name)
            .putLong(UpdateDownloadWorker.KEY_SIZE, info.apk.size)
            .putString(UpdateDownloadWorker.KEY_SHA, info.apk.sha256 ?: "")
            .build()
        val request = OneTimeWorkRequestBuilder<UpdateDownloadWorker>()
            .setInputData(data)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(appContext)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
        _state.value = UpdateState.Downloading(info, 0, 0L, info.apk.size)
        observe(request.id, info)
    }

    fun cancelDownload() {
        if (!initialized) return
        WorkManager.getInstance(appContext).cancelUniqueWork(WORK_NAME)
    }

    private fun observe(id: UUID, info: ReleaseInfo) {
        downloadJob?.cancel()
        downloadJob = scope.launch {
            WorkManager.getInstance(appContext).getWorkInfoByIdFlow(id).collect { workInfo ->
                if (workInfo == null) return@collect
                when (workInfo.state) {
                    WorkInfo.State.ENQUEUED, WorkInfo.State.RUNNING, WorkInfo.State.BLOCKED -> {
                        val downloaded = workInfo.progress.getLong(UpdateDownloadWorker.KEY_DOWNLOADED, 0L)
                        val total = workInfo.progress.getLong(UpdateDownloadWorker.KEY_TOTAL, info.apk.size)
                        val percent = if (total > 0) ((downloaded * 100) / total).toInt().coerceIn(0, 100) else 0
                        _state.value = UpdateState.Downloading(info, percent, downloaded, total)
                    }
                    WorkInfo.State.SUCCEEDED -> {
                        val path = workInfo.outputData.getString(UpdateDownloadWorker.KEY_PATH)
                        setDismissed(null)
                        if (path != null) {
                            _state.value = UpdateState.Ready(info, path)
                        } else {
                            _state.value = UpdateState.Error("Téléchargement terminé mais fichier introuvable.", info)
                        }
                    }
                    WorkInfo.State.FAILED -> {
                        setDismissed(null)
                        val message = workInfo.outputData.getString(UpdateDownloadWorker.KEY_ERROR)
                            ?: "Le téléchargement a échoué."
                        _state.value = UpdateState.Error(message, info)
                    }
                    WorkInfo.State.CANCELLED -> {
                        _state.value = UpdateState.Available(info, AppVersion.name(appContext))
                    }
                }
            }
        }
    }

    // ---------- Installation ----------

    fun install() {
        if (!initialized) return
        val (info, path) = when (val s = _state.value) {
            is UpdateState.Ready -> Pair(s.info, s.apkPath)
            is UpdateState.NeedsPermission -> Pair(s.info, s.apkPath)
            else -> return
        }
        val file = File(path)
        if (!file.exists()) {
            _state.value = UpdateState.Error("Le fichier de mise à jour a disparu. Télécharge-le de nouveau.", info)
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !appContext.packageManager.canRequestPackageInstalls()) {
            _state.value = UpdateState.NeedsPermission(info, path)
            val settings = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${appContext.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                appContext.startActivity(settings)
            } catch (e: ActivityNotFoundException) {
                _state.value = UpdateState.Error(
                    "Autorise l'installation d'applications inconnues pour ZAgent dans les paramètres Android.", info
                )
            }
            return
        }

        try {
            val uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.updateprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
        } catch (e: Exception) {
            _state.value = UpdateState.Error("Impossible de lancer l'installation : ${e.localizedMessage}", info)
        }
    }

    /** Appelé à chaque retour dans l'app : reprend l'installation une fois l'autorisation accordée. */
    fun onResume() {
        if (!initialized) return
        val s = _state.value
        if (s is UpdateState.NeedsPermission &&
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            appContext.packageManager.canRequestPackageInstalls()
        ) {
            _state.value = UpdateState.Ready(s.info, s.apkPath)
            install()
        }
    }

    fun dismiss(tag: String) {
        setDismissed(tag)
    }
}
EOF

cat > "$U/UpdateUi.kt" << 'EOF'
package com.zagent.app.update

import android.content.Context
import android.content.ContextWrapper
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay
import java.util.Locale

private fun mb(bytes: Long): String =
    String.format(Locale.getDefault(), "%.1f Mo", bytes / 1_048_576.0)

private fun findActivity(context: Context): ComponentActivity? {
    var current: Context? = context
    while (current is ContextWrapper) {
        if (current is ComponentActivity) return current
        current = current.baseContext
    }
    return null
}

/**
 * À placer une seule fois, tout en haut du contenu de l'Activity.
 * Vérifie automatiquement au démarrage et affiche les fenêtres de mise à jour.
 */
@Composable
fun UpdateHost() {
    val context = LocalContext.current
    remember { UpdateManager.init(context) }
    val state by UpdateManager.state.collectAsState()
    val dismissed by UpdateManager.dismissedTag.collectAsState()

    LaunchedEffect(Unit) {
        delay(1500)
        UpdateManager.check(auto = true)
    }

    DisposableEffect(context) {
        val activity = findActivity(context)
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) UpdateManager.onResume()
        }
        activity?.lifecycle?.addObserver(observer)
        onDispose { activity?.lifecycle?.removeObserver(observer) }
    }

    when (val s = state) {
        is UpdateState.Available -> if (s.info.tag != dismissed) AvailableDialog(s)
        is UpdateState.Downloading -> if (s.info.tag != dismissed) DownloadingDialog(s)
        is UpdateState.Ready -> if (s.info.tag != dismissed) ReadyDialog(s)
        is UpdateState.Error -> if (s.info != null && s.info.tag != dismissed) ErrorDialog(s, s.info)
        else -> Unit
    }
}

@Composable
private fun AvailableDialog(s: UpdateState.Available) {
    AlertDialog(
        onDismissRequest = { UpdateManager.dismiss(s.info.tag) },
        title = { Text("Mise à jour disponible") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Version ${s.info.tag.removePrefix("v")} (installée : ${s.currentVersion})")
                Text("Taille : ${mb(s.info.apk.size)}")
                if (s.info.apk.sha256 == null) {
                    Text(
                        "Empreinte SHA-256 non publiée : intégrité vérifiée par la taille et la signature Android.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(
                    s.info.notes,
                    modifier = Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState())
                )
            }
        },
        confirmButton = { TextButton(onClick = { UpdateManager.startDownload() }) { Text("Télécharger") } },
        dismissButton = { TextButton(onClick = { UpdateManager.dismiss(s.info.tag) }) { Text("Plus tard") } }
    )
}

@Composable
private fun DownloadingDialog(s: UpdateState.Downloading) {
    AlertDialog(
        onDismissRequest = { UpdateManager.dismiss(s.info.tag) },
        title = { Text("Téléchargement en cours") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LinearProgressIndicator(progress = { s.percent / 100f }, modifier = Modifier.fillMaxWidth())
                Text(
                    if (s.total > 0) "${s.percent} % · ${mb(s.downloaded)} / ${mb(s.total)}" else mb(s.downloaded)
                )
            }
        },
        confirmButton = { TextButton(onClick = { UpdateManager.dismiss(s.info.tag) }) { Text("Masquer") } },
        dismissButton = { TextButton(onClick = { UpdateManager.cancelDownload() }) { Text("Annuler") } }
    )
}

@Composable
private fun ReadyDialog(s: UpdateState.Ready) {
    AlertDialog(
        onDismissRequest = { UpdateManager.dismiss(s.info.tag) },
        title = { Text("Mise à jour prête") },
        text = { Text("La version ${s.info.tag.removePrefix("v")} est téléchargée et vérifiée. Android va te demander de confirmer l'installation.") },
        confirmButton = { TextButton(onClick = { UpdateManager.install() }) { Text("Installer") } },
        dismissButton = { TextButton(onClick = { UpdateManager.dismiss(s.info.tag) }) { Text("Plus tard") } }
    )
}

@Composable
private fun ErrorDialog(s: UpdateState.Error, info: ReleaseInfo) {
    AlertDialog(
        onDismissRequest = { UpdateManager.dismiss(info.tag) },
        title = { Text("Mise à jour impossible") },
        text = { Text(s.message) },
        confirmButton = { TextButton(onClick = { UpdateManager.startDownload() }) { Text("Réessayer") } },
        dismissButton = { TextButton(onClick = { UpdateManager.dismiss(info.tag) }) { Text("Fermer") } }
    )
}

/** Carte à placer dans l'écran des réglages : version installée + vérification manuelle. */
@Composable
fun UpdateSettingsCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    remember { UpdateManager.init(context) }
    val state by UpdateManager.state.collectAsState()

    Card(modifier = modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Mises à jour", style = MaterialTheme.typography.titleMedium)
            Text("Version installée : ${UpdateManager.currentVersionName()}", style = MaterialTheme.typography.bodyMedium)

            val status = when (val s = state) {
                UpdateState.Idle -> "Aucune vérification effectuée."
                UpdateState.Checking -> "Vérification en cours…"
                is UpdateState.UpToDate -> "L'application est à jour."
                is UpdateState.Available -> "Nouvelle version ${s.info.tag.removePrefix("v")} disponible (${mb(s.info.apk.size)})."
                is UpdateState.Downloading -> "Téléchargement : ${s.percent} %"
                is UpdateState.Ready -> "Mise à jour téléchargée et vérifiée."
                is UpdateState.NeedsPermission -> "Autorise l'installation dans les paramètres, puis reviens dans l'application."
                is UpdateState.Error -> s.message
            }
            Text(status, style = MaterialTheme.typography.bodyMedium)

            when (val s = state) {
                is UpdateState.Available -> Button(onClick = { UpdateManager.startDownload() }) { Text("Télécharger") }
                is UpdateState.Ready -> Button(onClick = { UpdateManager.install() }) { Text("Installer") }
                is UpdateState.NeedsPermission -> Button(onClick = { UpdateManager.install() }) { Text("Installer") }
                is UpdateState.Downloading -> LinearProgressIndicator(
                    progress = { s.percent / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
                UpdateState.Checking -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                is UpdateState.Error -> {
                    if (s.info != null) {
                        Button(onClick = { UpdateManager.startDownload() }) { Text("Réessayer") }
                    } else {
                        OutlinedButton(onClick = { UpdateManager.check(auto = false) }) { Text("Vérifier les mises à jour") }
                    }
                }
                else -> OutlinedButton(onClick = { UpdateManager.check(auto = false) }) { Text("Vérifier les mises à jour") }
            }
        }
    }
}
EOF

cat > app/src/main/res/xml/update_file_paths.xml << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<paths>
    <cache-path name="updates" path="updates/" />
</paths>
EOF

echo "== 3/7 Tests unitaires =="

cat > "$T/VersionComparatorTest.kt" << 'EOF'
package com.zagent.app.update

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VersionComparatorTest {

    @Test
    fun newerBuildNumberIsDetected() {
        assertTrue(VersionComparator.isNewer("v1.0-b12", "1.0-b11", 11L))
    }

    @Test
    fun sameBuildNumberIsNotNewer() {
        assertFalse(VersionComparator.isNewer("v1.0-b11", "1.0-b11", 11L))
    }

    @Test
    fun olderBuildNumberIsNotNewer() {
        assertFalse(VersionComparator.isNewer("v1.0-b5", "1.0-b11", 11L))
    }

    @Test
    fun buildNumberIsComparedToVersionCodeNotToName() {
        assertTrue(VersionComparator.isNewer("v2.0-b3", "1.0", 2L))
        assertFalse(VersionComparator.isNewer("v2.0-b3", "1.0", 3L))
    }

    @Test
    fun emptyOrGarbageTagIsNeverNewer() {
        assertFalse(VersionComparator.isNewer("", "1.0", 1L))
        assertFalse(VersionComparator.isNewer("v", "1.0", 1L))
        assertFalse(VersionComparator.isNewer("abc", "1.0", 1L))
    }

    @Test
    fun semanticVersionsAreComparedNumerically() {
        assertTrue(VersionComparator.isNewer("1.2.0", "1.1.9", 1L))
        assertTrue(VersionComparator.isNewer("1.10.0", "1.9.0", 1L))
        assertTrue(VersionComparator.isNewer("v2", "1.9.9", 1L))
        assertFalse(VersionComparator.isNewer("1.0.0", "1.0", 1L))
    }

    @Test
    fun preReleaseIsOlderThanFinalRelease() {
        assertFalse(VersionComparator.isNewer("1.2.0-rc1", "1.2.0", 1L))
        assertTrue(VersionComparator.isNewer("1.2.0", "1.2.0-rc1", 1L))
    }

    @Test
    fun buildNumberIsExtractedFromTag() {
        assertEquals(12L, VersionComparator.buildNumber("v1.0-b12"))
        assertNull(VersionComparator.buildNumber("1.0"))
        assertNull(VersionComparator.buildNumber("1.0-beta2"))
    }
}
EOF

cat > "$T/ReleaseParserTest.kt" << 'EOF'
package com.zagent.app.update

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReleaseParserTest {
    private val sha = "a".repeat(64)

    private val fullRelease = """
    {"tag_name":"v1.0-b7","body":"## Notes\n- Correction **chat**\n- Nouveau `agent`","assets":[
      {"name":"ZAgent-v1.0-b7.apk","size":1234,"browser_download_url":"https://example.com/a.apk","digest":"sha256:$sha"},
      {"name":"ZAgent-v1.0-b7.apk.sha256","size":100,"browser_download_url":"https://example.com/a.sha256"}
    ]}
    """.trimIndent()

    @Test
    fun parsesApkDigestAndNotes() {
        val result = ReleaseParser.parse(fullRelease) as ParseResult.Success
        assertEquals("v1.0-b7", result.info.tag)
        assertEquals("ZAgent-v1.0-b7.apk", result.info.apk.name)
        assertEquals(1234L, result.info.apk.size)
        assertEquals(sha, result.info.apk.sha256)
        assertNotNull(result.info.sha256Url)
        assertTrue(result.info.notes.contains("• Correction chat"))
        assertTrue(result.info.notes.contains("• Nouveau agent"))
    }

    @Test
    fun releaseWithoutApkIsRejected() {
        val json = """{"tag_name":"v1.0-b1","assets":[{"name":"notes.txt","size":1,"browser_download_url":"https://example.com/n.txt"}]}"""
        assertTrue(ReleaseParser.parse(json) is ParseResult.Failure)
    }

    @Test
    fun invalidJsonIsRejected() {
        assertTrue(ReleaseParser.parse("not json") is ParseResult.Failure)
    }

    @Test
    fun missingTagIsRejected() {
        assertTrue(ReleaseParser.parse("""{"assets":[]}""") is ParseResult.Failure)
    }

    @Test
    fun nullBodyAndMissingDigestAreHandled() {
        val json = """{"tag_name":"v1.0-b2","body":null,"assets":[{"name":"a.apk","size":10,"browser_download_url":"https://example.com/a.apk"}]}"""
        val result = ReleaseParser.parse(json) as ParseResult.Success
        assertNull(result.info.apk.sha256)
        assertNull(result.info.sha256Url)
        assertEquals("• Corrections et améliorations.", result.info.notes)
    }

    @Test
    fun invalidDigestIsIgnored() {
        assertNull(ReleaseParser.normalizeSha("pas-un-hash"))
        assertEquals(sha, ReleaseParser.normalizeSha(sha.uppercase()))
    }
}
EOF

echo "== 4/7 Câblage dans l'application =="

python - << 'PY'
import re, sys

# ---- app/build.gradle.kts : versions injectables, WorkManager, dépendances de test ----
p = "app/build.gradle.kts"
s = open(p, encoding="utf-8").read()

if 'findProperty("versionCode")' not in s:
    s, n = re.subn(r'(?m)^(\s*)versionCode\s*=\s*(\d+)\s*$',
                   r'\1versionCode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: \2', s)
    if n == 0:
        sys.exit("Ligne 'versionCode = <nombre>' introuvable dans app/build.gradle.kts : envoie-moi ce fichier.")
if 'findProperty("versionName")' not in s:
    s, n = re.subn(r'(?m)^(\s*)versionName\s*=\s*("[^"]*")\s*$',
                   r'\1versionName = (project.findProperty("versionName") as String?) ?: \2', s)
    if n == 0:
        sys.exit("Ligne 'versionName = \"...\"' introuvable dans app/build.gradle.kts : envoie-moi ce fichier.")

deps = []
if "work-runtime-ktx" not in s:
    deps.append('    implementation("androidx.work:work-runtime-ktx:2.9.1")')
if "junit:junit" not in s:
    deps.append('    testImplementation("junit:junit:4.13.2")')
if "org.json:json" not in s:
    deps.append('    testImplementation("org.json:json:20240303")')
if deps:
    matches = list(re.finditer(r'(?m)^\s*dependencies\s*\{', s))
    if not matches:
        sys.exit("Bloc dependencies { } introuvable dans app/build.gradle.kts : envoie-moi ce fichier.")
    m = matches[-1]
    s = s[:m.end()] + "\n" + "\n".join(deps) + s[m.end():]
open(p, "w", encoding="utf-8").write(s)
print("build.gradle.kts : OK")

# ---- AndroidManifest.xml : permission + FileProvider dédié ----
p = "app/src/main/AndroidManifest.xml"
s = open(p, encoding="utf-8").read()
if "REQUEST_INSTALL_PACKAGES" not in s:
    i = s.index("<application")
    s = s[:i] + '<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />\n    ' + s[i:]
if "UpdateFileProvider" not in s:
    provider = '''<provider
            android:name="com.zagent.app.update.UpdateFileProvider"
            android:authorities="${applicationId}.updateprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/update_file_paths" />
        </provider>
    '''
    j = s.rindex("</application>")
    s = s[:j] + provider + s[j:]
open(p, "w", encoding="utf-8").write(s)
print("AndroidManifest.xml : OK")
PY

python - << 'PY'
import glob, re, sys

def add_import(src, line):
    if line in src:
        return src
    parts = src.split("\n")
    for i, l in enumerate(parts):
        if l.startswith("import "):
            parts.insert(i, line)
            return "\n".join(parts)
    sys.exit("Aucun import trouvé pour ajouter : " + line)

# ---- MainActivity : UpdateHost() au début du contenu ----
files = glob.glob("app/src/main/java/**/MainActivity.kt", recursive=True)
if not files:
    sys.exit("MainActivity.kt introuvable.")
p = files[0]
s = open(p, encoding="utf-8").read()
if "UpdateHost()" not in s:
    m = re.search(r'setContent\s*\{', s)
    if not m:
        sys.exit("setContent { introuvable dans MainActivity.kt : envoie-moi ce fichier.")
    pos = m.end()
    t = re.match(r'\s*\w*Theme\w*\s*(\([^)]*\))?\s*\{', s[pos:])
    if t:
        pos += t.end()
    s = s[:pos] + "\n            UpdateHost()" + s[pos:]
    s = add_import(s, "import com.zagent.app.update.UpdateHost")
    open(p, "w", encoding="utf-8").write(s)
print("MainActivity :", p)

# ---- SettingsScreen : carte de mise à jour avant le premier séparateur ----
files = glob.glob("app/src/main/java/**/SettingsScreen.kt", recursive=True)
if not files:
    print("⚠ SettingsScreen.kt introuvable : ajoute UpdateSettingsCard() à la main.")
    sys.exit(0)
p = files[0]
s = open(p, encoding="utf-8").read()
if "UpdateSettingsCard()" in s:
    print("SettingsScreen déjà câblé")
    sys.exit(0)
lines = s.split("\n")
done = False
for i, l in enumerate(lines):
    st = l.strip()
    if st.startswith("Divider(") or st.startswith("HorizontalDivider("):
        indent = l[:len(l) - len(l.lstrip())]
        lines.insert(i, indent + "UpdateSettingsCard()")
        done = True
        break
if not done:
    print("⚠ Aucun séparateur trouvé dans SettingsScreen.kt : ajoute UpdateSettingsCard() à la main.")
    sys.exit(0)
s = add_import("\n".join(lines), "import com.zagent.app.update.UpdateSettingsCard")
open(p, "w", encoding="utf-8").write(s)
print("SettingsScreen :", p)
PY

echo "== 5/7 Workflow de release =="

GV=$(grep -hoE "gradle-version:[[:space:]]*['\"]?[0-9A-Za-z._-]+" .github/workflows/*.yml 2>/dev/null | head -1 | sed -E "s/.*:[[:space:]]*['\"]?//")
GV=${GV:-current}
JV=$(grep -hoE "java-version:[[:space:]]*['\"]?[0-9]+" .github/workflows/*.yml 2>/dev/null | head -1 | sed -E "s/.*:[[:space:]]*['\"]?//")
JV=${JV:-21}

cat > .github/workflows/release.yml << 'EOF'
name: Release APK

# Lancement manuel : gh workflow run release.yml -f version=1.0 -f notes="Nouveautés"
on:
  workflow_dispatch:
    inputs:
      version:
        description: "Version de base (ex : 1.0)"
        required: true
        default: "1.0"
      notes:
        description: "Nouveautés affichées dans l'application (une par ligne)"
        required: false
        default: ""

permissions:
  contents: write

concurrency:
  group: release
  cancel-in-progress: false

jobs:
  release:
    runs-on: ubuntu-latest
    env:
      BASE_VERSION: ${{ github.event.inputs.version }}
      RELEASE_NOTES: ${{ github.event.inputs.notes }}
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: JDK
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "__JAVA_VERSION__"

      - name: Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: "__GRADLE_VERSION__"

      - name: Licences Android
        run: yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses || true

      - name: Calculer la version
        id: ver
        run: |
          case "$BASE_VERSION" in
            ''|*[!0-9A-Za-z._]*) echo "Version invalide : $BASE_VERSION"; exit 1;;
          esac
          CODE="${{ github.run_number }}"
          NAME="${BASE_VERSION}-b${CODE}"
          echo "code=$CODE" >> "$GITHUB_OUTPUT"
          echo "name=$NAME" >> "$GITHUB_OUTPUT"
          echo "tag=v$NAME" >> "$GITHUB_OUTPUT"
          echo "Version $NAME (versionCode $CODE)"

      - name: Préparer la signature
        env:
          KS_B64: ${{ secrets.KEYSTORE_BASE64 }}
          KS_PASS: ${{ secrets.KEYSTORE_PASSWORD }}
          KS_ALIAS: ${{ secrets.KEY_ALIAS }}
        run: |
          echo "$KS_B64" | base64 -d > "$RUNNER_TEMP/release.keystore"
          {
            echo "KEYSTORE_PATH=$RUNNER_TEMP/release.keystore"
            echo "KEYSTORE_PASSWORD=$KS_PASS"
            echo "KEY_PASSWORD=$KS_PASS"
            echo "KEY_ALIAS=$KS_ALIAS"
          } >> "$GITHUB_ENV"

      - name: Tests unitaires
        run: gradle :app:testDebugUnitTest

      - name: Lint (informatif)
        continue-on-error: true
        run: gradle :app:lintDebug

      - name: Build release signé
        run: gradle assembleRelease -PversionName=${{ steps.ver.outputs.name }} -PversionCode=${{ steps.ver.outputs.code }}

      - name: Nommer l'APK et calculer le SHA-256
        run: |
          mkdir -p dist
          APK=$(ls app/build/outputs/apk/release/*.apk | head -1)
          OUT="ZAgent-${{ steps.ver.outputs.tag }}.apk"
          cp "$APK" "dist/$OUT"
          (cd dist && sha256sum "$OUT" > "$OUT.sha256" && cat "$OUT.sha256")

      - name: Vérifier la signature de l'APK
        run: |
          APKSIGNER=$(find "$ANDROID_HOME/build-tools" -name apksigner 2>/dev/null | sort -V | tail -1)
          if [ -z "$APKSIGNER" ]; then echo "apksigner introuvable"; exit 1; fi
          "$APKSIGNER" verify --verbose --print-certs dist/ZAgent-${{ steps.ver.outputs.tag }}.apk

      - name: Archiver les fichiers
        uses: actions/upload-artifact@v4
        with:
          name: zagent-release
          path: dist/*
          retention-days: 30

      - name: Notes de version
        run: |
          if [ -n "$RELEASE_NOTES" ]; then
            printf '%s\n' "$RELEASE_NOTES" > notes.md
          else
            git log -1 --pretty=%s > notes.md
          fi

      - name: Publier la release
        uses: softprops/action-gh-release@v2
        with:
          tag_name: ${{ steps.ver.outputs.tag }}
          name: "ZAgent ${{ steps.ver.outputs.name }}"
          body_path: notes.md
          files: |
            dist/*.apk
            dist/*.sha256
          fail_on_unmatched_files: true
EOF
sed -i "s/__GRADLE_VERSION__/$GV/; s/__JAVA_VERSION__/$JV/" .github/workflows/release.yml
echo "Workflow : gradle $GV, JDK $JV"

echo "== 6/7 Envoi sur GitHub =="
git add -A
git commit -m "Système de mise à jour: WorkManager, SHA-256, tests et workflow de release" || echo "Rien à committer"
git push

echo "== 7/7 Suivi du build de contrôle =="
sleep 10
ID=$(gh run list --limit 1 --json databaseId -q '.[0].databaseId')
if [ -n "$ID" ]; then
  gh run watch "$ID" --exit-status || echo "⚠ Le build a échoué : envoie-moi le bloc 'What went wrong'."
fi

if [ "$1" = "--release" ]; then
  echo "== Publication de la release 1.0 =="
  gh workflow run release.yml -f version=1.0 -f notes="Système de mise à jour intégré"
  sleep 10
  RID=$(gh run list --workflow release.yml --limit 1 --json databaseId -q '.[0].databaseId')
  gh run watch "$RID" --exit-status
  echo "Release publiée. Pour tester la mise à jour : installe cette APK, puis republie avec la commande ci-dessous."
fi

echo ""
echo "Publier une release :"
echo "  gh workflow run release.yml -f version=1.0 -f notes=\"Ce qui change\""
